<?php
/**
 * Options for the Page Redirect plugin
 */
$conf['enabled_langs']    = 'en';  // Enabled language
$conf['flags']            = false; // Do not show flags.
$conf['use_browser_lang'] =  true; // Check browser ui for language setting.
$conf['start_redirect']   = false; // Redirect to the language start parge
$conf['skiptrans']        = '';
$conf['about']            = '';

